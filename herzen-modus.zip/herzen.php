<?php
// Version 1.0
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

$user = $_SESSION['discord_user'] ?? null;
if (!$user) {
    header('Location: index.php');
    exit;
}

$code = strtoupper($_GET['code'] ?? '');
$stmt = db()->prepare('SELECT id, host_id, mode FROM kr_rooms WHERE code = ?');
$stmt->execute([$code]);
$room = $stmt->fetch();
if (!$room) {
    die('Raum nicht gefunden. <a href="lobby.php">Zurück</a>');
}

// Im Punkte-Modus geht es zurück zum Spielfeld
if ($room['mode'] !== 'hearts') {
    header('Location: board.php?code=' . urlencode($code));
    exit;
}

$isHost = $room['host_id'] === $user['id'];

db()->prepare('
    INSERT INTO kr_room_players (room_id, discord_id, username, avatar, team_id, last_seen)
    VALUES (?, ?, ?, ?, NULL, NOW())
    ON DUPLICATE KEY UPDATE username = VALUES(username), avatar = VALUES(avatar), last_seen = NOW()
')->execute([(int)$room['id'], $user['id'], $user['name'] ?? $user['username'], $user['avatar']]);
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Herzen-Modus <?= htmlspecialchars($code) ?> – <?= APP_NAME ?></title>
    <style>
        body { font-family: system-ui, sans-serif; background: #1f1438; color: #f5f0ff; margin: 0; padding: 24px; }
        a { color: #7fe7d9; }
        h1 { margin: 10px 0 14px; font-size: 22px; }
        .topbar { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; }
        .btn {
            padding: 10px 16px; border: none; border-radius: 10px; background: #7b2ff7; color: #fff;
            font-weight: bold; cursor: pointer; font-size: 15px;
        }
        .btn:hover:not(:disabled) { filter: brightness(1.1); }
        .btn:disabled { opacity: .4; cursor: default; }
        .btn.grey { background: #444; }
        .btn.danger { background: #ff3b5c; }
        .btn.small { padding: 6px 10px; font-size: 13px; }
        select { padding: 9px 10px; border-radius: 10px; border: none; background: #3b2a6b; color: #fff; font: inherit; }

        /* Zentrales Banner */
        .banner {
            background: linear-gradient(160deg, #2c1d52, #1a1030);
            border: 3px solid #3ddbc4; border-radius: 20px; padding: 26px; margin: 18px 0 24px;
            text-align: center; box-shadow: 0 10px 30px rgba(0,0,0,.4);
        }
        .bl { font-size: 15px; opacity: .85; margin-bottom: 10px; }
        .who { font-size: 22px; font-weight: bold; margin-bottom: 6px; }
        .timer { font-size: 40px; font-weight: bold; color: #f5b400; font-variant-numeric: tabular-nums; }
        .qtext { font-size: 26px; font-weight: bold; margin: 14px 0; white-space: pre-wrap; line-height: 1.3; }
        .qans { font-size: 17px; padding: 10px; border-radius: 10px; background: rgba(255,210,0,.15); border: 2px dashed #f5b400; display: inline-block; }
        .row { display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; margin-top: 16px; align-items: center; }
        .info { margin: 8px 0; font-size: 16px; }
        .muted { opacity: .65; font-size: 14px; }
        .wrongs { text-align: left; margin: 14px auto; max-width: 720px; }
        .wrong { background: rgba(255,255,255,.05); border-radius: 10px; padding: 10px 14px; margin-bottom: 8px; }
        .wrong .item { font-size: 14px; margin-top: 4px; opacity: .9; }
        .votes { display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; margin-top: 12px; }
        .votebtn.sel { outline: 3px solid #fff; }
        .out { color: #ff8a8a; font-weight: bold; }

        /* Spielerkarten */
        .cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(170px, 1fr)); gap: 16px; }
        .card {
            background: #2c1d52; border: 3px solid #666; border-radius: 16px; padding: 14px 10px 12px;
            text-align: center; transition: transform .2s ease, border-color .2s ease;
        }
        .card.current { border-color: #f5b400; box-shadow: 0 0 22px rgba(245,180,0,.55); transform: scale(1.03); }
        .card.out { filter: grayscale(1); opacity: .45; }
        .card.me { border-color: #3ddbc4; }
        .card.me.current { border-color: #f5b400; }
        .avwrap { position: relative; width: 84px; height: 84px; margin: 0 auto 8px; }
        .avwrap img.av { width: 84px; height: 84px; border-radius: 50%; border: 3px solid #3ddbc4; background: #1a1030; box-sizing: border-box; }
        .avwrap img.deco { position: absolute; left: -17%; top: -17%; width: 134%; height: 134%; pointer-events: none; }
        .cname { font-weight: bold; font-size: 15px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .hearts { margin: 8px 0 4px; font-size: 22px; letter-spacing: 3px; }
        .h.on { color: #ff3b5c; }
        .h.off { color: #555; }
        .joker { font-size: 22px; }
        .joker.used { filter: grayscale(1); opacity: .35; }
        .joker.active { filter: drop-shadow(0 0 6px #f5d000); }
        .status { font-size: 12px; opacity: .75; margin-top: 4px; }

        @media (max-width: 700px) {
            body { padding: 14px; }
            .timer { font-size: 32px; }
            .qtext { font-size: 20px; }
            .cards { grid-template-columns: repeat(2, 1fr); }
        }
    </style>
</head>
<body>
    <div class="topbar">
        <a href="lobby.php">← Lobby</a>
        <?php if ($isHost): ?>
            <select id="modeSel">
                <option value="points">Modus: Punkte</option>
                <option value="hearts" selected>Modus: Herzen</option>
            </select>
        <?php endif; ?>
    </div>

    <h1>Herzen-Modus – Raum <?= htmlspecialchars($code) ?></h1>

    <div class="banner" id="banner">Lade …</div>

    <div class="cards" id="cards"></div>

    <script>
        const roomCode = <?= json_encode($code) ?>;
        const myId = <?= json_encode($user['id']) ?>;
        const isHost = <?= json_encode($isHost) ?>;
        const LABEL = {
            idle: 'Bereit', asking: 'Frage', answered: 'Bewertet',
            voting: 'Abstimmung', result: 'Auswertung', finished: 'Spielende',
        };
        const ERRORS = {
            running: 'Das Spiel läuft schon.',
            few: 'Mindestens 2 Spieler werden gebraucht.',
            noquestion: 'In dieser Kategorie sind keine Fragen mehr übrig.',
            noactive: 'Gerade nicht möglich.',
            nojoker: 'Joker schon verbraucht oder ausgeschieden.',
            notyours: 'Du bist nicht dran.',
            input: 'Ungültige Eingabe.',
            host: 'Nur der Host darf das.',
            out: 'Du bist ausgeschieden.',
        };

        const banner = document.getElementById('banner');
        const cardsEl = document.getElementById('cards');
        let S = null;
        let lastSig = '';

        function el(tag, cls = '', text = '') {
            const e = document.createElement(tag);
            if (cls) e.className = cls;
            if (text) e.textContent = text;
            return e;
        }

        function button(label, cls, onClick) {
            const b = el('button', 'btn ' + cls, label);
            b.type = 'button';
            b.addEventListener('click', onClick);
            return b;
        }

        async function load() {
            try {
                const res = await fetch('herzen_api.php?code=' + encodeURIComponent(roomCode), { cache: 'no-store' });
                if (res.ok) {
                    S = await res.json();
                    if (S.mode === 'points') {
                        location.href = 'board.php?code=' + encodeURIComponent(roomCode);
                        return;
                    }
                    render();
                }
            } catch (e) {
                // nächster Durchlauf versucht es erneut
            }
            setTimeout(load, 1000);
        }

        async function act(action, data = {}) {
            const body = new URLSearchParams({ code: roomCode, action, ...data });
            const res = await fetch('herzen_api.php', { method: 'POST', body, cache: 'no-store' });
            if (!res.ok) {
                const j = await res.json().catch(() => ({}));
                alert(ERRORS[j.error] || 'Fehler.');
            }
            load();
        }

        function render() {
            const sig = JSON.stringify(S);
            if (sig === lastSig) return;
            lastSig = sig;
            renderBanner();
            renderCards();
        }

        function renderBanner() {
            banner.innerHTML = '';
            const ph = S.phase;
            const me = S.players.find(p => p.is_me);

            banner.append(el('div', 'bl', `Runde ${S.round} · ${LABEL[ph] || ''}` + (S.category ? ` · ${S.category}` : '')));

            if (ph === 'idle') {
                if (isHost) {
                    const sel = document.createElement('select');
                    for (const c of S.categories) sel.append(new Option(c.name, String(c.id)));
                    const row = el('div', 'row');
                    row.append(el('span', '', 'Kategorie:'), sel, button('Spiel starten', '', () => act('start', { category_id: sel.value })));
                    banner.append(row);
                } else {
                    banner.append(el('p', 'info', 'Warte, bis der Host das Spiel startet.'));
                }
            }

            if (ph === 'asking') {
                const cur = S.players.find(p => p.is_current);
                banner.append(el('div', 'who', cur ? (cur.is_me ? 'Du bist dran' : `${cur.name} ist dran`) : ''));
                banner.append(el('div', 'timer', `⏱ ${S.secondsLeft ?? 0} s`));
                if (S.viaJoker) banner.append(el('p', 'info', '🃏 Frage per Joker weitergegeben'));
                if (S.question) {
                    banner.append(el('div', 'qtext', S.question.text));
                    if (isHost && S.question.answer) {
                        banner.append(el('div', 'qans', 'Antwort: ' + S.question.answer));
                    }
                }
                if (isHost) {
                    const row = el('div', 'row');
                    row.append(
                        button('✓ richtig', '', () => act('mark', { correct: '1' })),
                        button('✗ falsch', 'danger', () => act('mark', { correct: '0' })),
                    );
                    banner.append(row);
                }
                if (S.jokerAvailable) {
                    const sel = document.createElement('select');
                    for (const p of S.players) {
                        if (p.is_me || p.eliminated) continue;
                        sel.append(new Option(p.name, p.discord_id));
                    }
                    const row = el('div', 'row');
                    row.append(el('span', '', '🃏 weitergeben an:'), sel,
                        button('Joker einsetzen', 'grey', () => act('joker', { target: sel.value })));
                    banner.append(row);
                }
            }

            if (ph === 'answered') {
                banner.append(el('p', 'info', 'Antwort bewertet.'));
                if (isHost) {
                    const row = el('div', 'row');
                    row.append(button('Weiter', '', () => act('next')));
                    banner.append(row);
                }
            }

            if (ph === 'voting') {
                banner.append(el('p', 'info', 'Die falschen Antworten dieser Runde:'));
                const wl = el('div', 'wrongs');
                if (S.wrongs.length === 0) {
                    wl.append(el('p', 'info', 'Niemand hat falsch geantwortet.'));
                }
                for (const w of S.wrongs) {
                    const box = el('div', 'wrong');
                    box.append(el('strong', '', w.name));
                    for (const it of w.items) {
                        box.append(el('div', 'item', `„${it.q}“ – richtig wäre: ${it.a}`));
                    }
                    wl.append(box);
                }
                banner.append(wl);

                if (me && me.eliminated) {
                    banner.append(el('p', 'out', 'Du bist ausgeschieden und kannst nicht abstimmen.'));
                } else {
                    banner.append(el('p', 'info', 'Wer hat die dümmsten Fehler gemacht?'));
                    const votes = el('div', 'votes');
                    for (const p of S.players) {
                        if (p.is_me || p.eliminated) continue;
                        const b = button(p.name, 'grey votebtn' + (S.vote.mine === p.discord_id ? ' sel' : ''), () => act('vote', { target: p.discord_id }));
                        votes.append(b);
                    }
                    banner.append(votes);
                    banner.append(el('p', 'muted', `Stimmen: ${S.vote.count} von ${S.aliveCount}`));
                }
                if (isHost) {
                    const row = el('div', 'row');
                    row.append(button('Auswerten', '', () => act('tally')));
                    banner.append(row);
                }
            }

            if (ph === 'result') {
                const max = S.tally.length ? S.tally[0].votes : 0;
                const losers = S.tally.filter(t => t.votes === max && max > 0);
                if (losers.length) {
                    banner.append(el('p', 'info', 'Verliert ein Herz: ' + losers.map(l => l.name).join(', ')));
                } else {
                    banner.append(el('p', 'info', 'Keine Stimmen abgegeben.'));
                }
                if (isHost) {
                    const row = el('div', 'row');
                    row.append(button('Nächste Runde', '', () => act('nextround')));
                    banner.append(row);
                }
            }

            if (ph === 'finished') {
                banner.append(el('div', 'qtext', S.winner ? `🏆 ${S.winner} gewinnt!` : 'Spiel beendet'));
            }

            if (isHost && ph !== 'idle') {
                const row = el('div', 'row');
                row.append(button('Spiel zurücksetzen', 'danger small', () => {
                    if (confirm('Spiel wirklich zurücksetzen?')) act('reset');
                }));
                banner.append(row);
            }
        }

        function renderCards() {
            cardsEl.innerHTML = '';
            for (const p of S.players) {
                const cls = 'card' + (p.is_current ? ' current' : '') + (p.eliminated ? ' out' : '') + (p.is_me ? ' me' : '');
                const card = el('div', cls);

                const av = el('div', 'avwrap');
                const img = el('img', 'av');
                img.src = p.avatar_url;
                img.alt = '';
                av.append(img);
                if (p.decoration_url) {
                    const deco = el('img', 'deco');
                    deco.src = p.decoration_url;
                    deco.alt = '';
                    av.append(deco);
                }

                const hearts = el('div', 'hearts');
                for (let i = 0; i < 3; i++) {
                    hearts.append(el('span', 'h ' + (i < p.hearts ? 'on' : 'off'), '♥'));
                }

                const joker = el('div', 'joker ' + (p.joker_used ? 'used' : 'active'), '🃏');

                card.append(av, el('div', 'cname', (p.premium ? '💎 ' : '') + p.name), hearts, joker);
                card.append(el('div', 'status', p.eliminated ? 'ausgeschieden' : (p.is_current ? 'am Zug' : '')));
                cardsEl.append(card);
            }
        }

        if (isHost) {
            document.getElementById('modeSel').addEventListener('change', async (e) => {
                if (e.target.value !== 'points') return;
                const keep = confirm('Punkte behalten?\nOK = ja, Abbrechen = Punkte auf 0 setzen');
                await fetch('herzen_api.php', {
                    method: 'POST',
                    body: new URLSearchParams({ code: roomCode, action: 'set_mode', mode: 'points', keep: keep ? '1' : '0' }),
                });
                location.href = 'board.php?code=' + encodeURIComponent(roomCode);
            });
        }

        load();
    </script>
</body>
</html>
<!-- Version 1.0 -->
